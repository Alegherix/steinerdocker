import './editor.scss';

export default function Edit(props) {
	console.log({props})
	console.log({wp})
	return (
		<p>
			My New Test Block – hello from the editor??? new update again!?!? lol
		</p>
	);
}
