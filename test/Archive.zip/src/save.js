export default function save(props) {
	console.log({props})
	return (
		<p className="wp-block-create-block-mynewtestblock">
				'My New Test Block – hello from the saved content! update lol'
		</p>
	);
}
